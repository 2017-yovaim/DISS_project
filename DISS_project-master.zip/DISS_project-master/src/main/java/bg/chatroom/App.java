package bg.chatroom;

import bg.chatroom.ui.util.SceneController;
import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage stage) {
        SceneController.setPrimaryStage(stage, "login");
    }

    public static void main(String[] args) {
        launch(args);
    }
}

