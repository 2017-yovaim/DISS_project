package bg.chatroom.validation;

import bg.chatroom.services.AuthService.AuthResult;

import java.util.regex.Pattern;

public class Validators {

    private static final Pattern EMAIL =
            Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    private static final Pattern ALLOWED_PASSWORD =
            Pattern.compile("^[A-Za-z0-9_\\-@!]{6,32}$");

    private static final Pattern HAS_LOWER =
            Pattern.compile(".*[a-z].*");

    private static final Pattern HAS_UPPER =
            Pattern.compile(".*[A-Z].*");

    private static final Pattern HAS_DIGIT =
            Pattern.compile(".*[0-9].*");

    private static final Pattern HAS_SPECIAL =
            Pattern.compile(".*[_\\-@!].*");

    public static AuthResult validateUsername(String username) {
        if (username == null || username.isBlank())
            return AuthResult.fail("Please enter a username.");

        if (username.length() < 3)
            return AuthResult.fail("Username must be at least 3 characters long.");

        return AuthResult.success();
    }

    public static AuthResult validateEmail(String email) {
        if (email == null || email.isBlank())
            return AuthResult.fail("Please enter an email address.");

        if (!EMAIL.matcher(email).matches())
            return AuthResult.fail("Please enter a valid email address.");

        return AuthResult.success();
    }

    public static AuthResult validatePassword(String password) {
        if (password == null || password.isBlank())
            return AuthResult.fail("Please enter a password.");

        if (!ALLOWED_PASSWORD.matcher(password).matches())
            return AuthResult.fail(
                    "Password must be 6 to 32 characters long and may contain letters, numbers, and _ - @ !"
            );

        if (!HAS_LOWER.matcher(password).matches())
            return AuthResult.fail("Password must contain at least one lowercase letter.");

        if (!HAS_UPPER.matcher(password).matches())
            return AuthResult.fail("Password must contain at least one uppercase letter.");

        if (!HAS_DIGIT.matcher(password).matches())
            return AuthResult.fail("Password must contain at least one digit.");

        if (!HAS_SPECIAL.matcher(password).matches())
            return AuthResult.fail("Password must contain at least one special character: _ - @ !");

        return AuthResult.success();
    }
}
