package bg.chatroom.di;

import bg.chatroom.services.AuthService;
import bg.chatroom.services.UserService;
import bg.chatroom.services.mock.MockAuthService;
import bg.chatroom.services.mock.MockUserService;

public final class ServiceLocator {
    private static final AuthService AUTH = new MockAuthService();
    private static final UserService USERS = new MockUserService();

    private ServiceLocator() {}

    public static AuthService auth() { return AUTH; }
    public static UserService users() { return USERS; }
}
