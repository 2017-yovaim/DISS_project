package bg.chatroom.services.mock;

import bg.chatroom.model.User;
import bg.chatroom.services.AuthService;
import bg.chatroom.services.UserService;
import bg.chatroom.ui.state.SessionState;

public class MockUserService implements UserService {

    @Override
    public AuthService.AuthResult updateUser(User updated) {
        var current = SessionState.getCurrentUser();
        if (current == null) return AuthService.AuthResult.fail("Not logged in.");

        // apply only changed fields (simple demo)
        if (updated.getUsername() != null) current.setUsername(updated.getUsername());
        if (updated.getEmail() != null) current.setEmail(updated.getEmail());
        if (updated.getPassword() != null) current.setPassword(updated.getPassword());
        if (updated.getName() != null) current.setName(updated.getName());
        if (updated.getAddress() != null) current.setAddress(updated.getAddress());
        if (updated.getSex() != null) current.setSex(updated.getSex());
        if (updated.getBirthdate() != null) current.setBirthdate(updated.getBirthdate());

        return AuthService.AuthResult.success();
    }
}
