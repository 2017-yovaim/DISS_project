package bg.chatroom.services;

public interface AuthService {
    AuthResult login(String usernameOrEmail, String password);

    AuthResult register(String username, String email, String password);

    record AuthResult(boolean ok, String message) {

        public static AuthResult success() {
            return new AuthResult(true, "OK");
        }

        public static AuthResult fail(String msg) {
            return new AuthResult(false, msg);
        }
    }
}