package bg.chatroom.services;

import bg.chatroom.model.User;

public interface UserService {
    AuthService.AuthResult updateUser(User updated); // updates current user fields
}
