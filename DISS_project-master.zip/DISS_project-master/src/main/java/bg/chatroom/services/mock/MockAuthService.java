package bg.chatroom.services.mock;

import bg.chatroom.services.AuthService;
import bg.chatroom.validation.Validators;

import java.util.HashSet;
import java.util.Set;

public class MockAuthService implements AuthService {

    private final Set<String> usernames = new HashSet<>();
    private final Set<String> emails = new HashSet<>();

    public MockAuthService() {
        // demo акаунт
        usernames.add("Ali");
        emails.add("ali@mail.com");
    }

    @Override
    public AuthResult login(String usernameOrEmail, String password) {
        if (usernameOrEmail == null || usernameOrEmail.isBlank()) return AuthResult.fail("Enter username or email.");
        if (password == null || password.isBlank()) return AuthResult.fail("Enter password.");

        // demo логика
        if ((usernames.contains(usernameOrEmail) || emails.contains(usernameOrEmail)) && "Password1!".equals(password)) {
            return AuthResult.success();
        }
        return AuthResult.fail("Wrong Login data (demo: Ali / Password1!).");
    }

    @Override
    public AuthResult register(String username, String email, String password) {
        var u = Validators.validateUsername(username);
        if (!u.ok()) return AuthResult.fail(u.message());

        var e = Validators.validateEmail(email);
        if (!e.ok()) return AuthResult.fail(e.message());

        var p = Validators.validatePassword(password);
        if (!p.ok()) return AuthResult.fail(p.message());

        if (usernames.contains(username)) return AuthResult.fail("Username already exists.");
        if (emails.contains(email)) return AuthResult.fail("Email is already registered.");

        usernames.add(username);
        emails.add(email);
        return AuthResult.success();
    }
}


