package bg.chatroom.ui.state;

import bg.chatroom.model.User;

public final class SessionState {
    private static User currentUser;

    private SessionState() {}

    public static User getCurrentUser() { return currentUser; }
    public static void setCurrentUser(User u) { currentUser = u; }
    public static void clear() { currentUser = null; }
    public static boolean isLoggedIn() { return currentUser != null; }
}
