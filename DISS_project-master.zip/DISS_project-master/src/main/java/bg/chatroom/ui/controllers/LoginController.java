package bg.chatroom.ui.controllers;

import bg.chatroom.di.ServiceLocator;
import bg.chatroom.model.User;
import bg.chatroom.ui.state.SessionState;
import bg.chatroom.ui.util.SceneController;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

import java.util.function.UnaryOperator;

public class LoginController {

    @FXML private HBox screen;

    @FXML private HBox alert;
    @FXML private Text alertText;

    @FXML private TextField username;
    @FXML private PasswordField password;

    @FXML
    public void initialize() {
        if (alert != null) alert.setVisible(false);

        // Enter key triggers login
        if (screen != null) {
            screen.setFocusTraversable(true);
            screen.setOnKeyReleased(e -> {
                if (e.getCode() == KeyCode.ENTER) login();
            });
            screen.setOnMouseClicked(e -> screen.requestFocus());
        }

        UnaryOperator<TextFormatter.Change> limit32 =
                c -> c.getControlNewText().length() > 32 ? null : c;

        username.setTextFormatter(new TextFormatter<>(limit32));
        password.setTextFormatter(new TextFormatter<>(limit32));
    }

    @FXML
    void login() {
        hideError();

        String u = username.getText() == null ? "" : username.getText().trim();
        String p = password.getText() == null ? "" : password.getText();

        var res = ServiceLocator.auth().login(u, p);
        if (res.ok()) {
            SessionState.setCurrentUser(new User(u, "ali@mail.com", "Ali", p)); // demo
            SceneController.setScene("chat");
        } else {
            showError(res.message());
        }
    }

    @FXML
    void switchToRegister() {
        SceneController.setScene("register");
    }

    @FXML
    void switchToForgotPassword() {
        showError("Forgot password screen will be added later.");
    }

    private void showError(String msg) {
        if (alertText != null) alertText.setText(msg);
        if (alert != null) alert.setVisible(true);
    }

    private void hideError() {
        if (alert != null) alert.setVisible(false);
    }
}
