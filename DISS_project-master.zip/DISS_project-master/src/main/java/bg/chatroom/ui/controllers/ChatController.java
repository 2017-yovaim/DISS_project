package bg.chatroom.ui.controllers;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;
import javafx.util.Duration;
import bg.chatroom.ui.state.SessionState;
import bg.chatroom.ui.util.SceneController;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import javafx.geometry.VPos;


public class ChatController {

    // ---------- Small UI-only models ----------
    public static final class Conversation {
        public final long id;
        public final String name;
        public final boolean isGroup;

        public String latestMessage;
        public Instant latestTime;
        public boolean isSeen;

        public Conversation(long id, String name, boolean isGroup) {
            this.id = id;
            this.name = name;
            this.isGroup = isGroup;
            this.latestMessage = "";
            this.latestTime = null;
            this.isSeen = true;
        }
    }

    public static final class Msg {
        public final long id;
        public final long conversationId;
        public final String sender; // null = system message
        public final Instant time;
        public final String text;

        public Msg(long id, long conversationId, String sender, Instant time, String text) {
            this.id = id;
            this.conversationId = conversationId;
            this.sender = sender;
            this.time = time;
            this.text = text;
        }
    }

    // ---------- State ----------
    private final ObservableList<Conversation> conversations = FXCollections.observableArrayList();
    private final ObservableList<Msg> messages = FXCollections.observableArrayList();

    private final Map<Long, GridPane> conversationNodeById = new HashMap<>();
    private final Map<Long, VBox> messageNodeById = new HashMap<>();
    private final Map<Long, List<Msg>> messagesByConversation = new HashMap<>();

    private Conversation focused;

    // Navigation callbacks
    private Runnable goLogin;
    private Runnable goFriends;
    private Runnable goAccount;

    // ---------- FXML fields ----------
    @FXML private VBox chatArea;
    @FXML private TextField chatField;
    @FXML private VBox chatList;
    @FXML private StackPane mainChatContainer;
    @FXML private ScrollPane chatScrollPane;

    @FXML private GridPane screen;
    @FXML private TextField searchChatList;
    @FXML private TextField searchMessage;

    @FXML private Text headerName;
    @FXML private Text headerStatus;

    @FXML private VBox rightSideBar;
    @FXML private VBox rightSideBarGroup;

    @FXML private Text rightSideBarName;
    @FXML private Text rightSideBarStatus;

    @FXML private Text rightSideBarGroupName;
    @FXML private Text rightSideBarStatusGroup;

    @FXML private VBox groupMemberContainer;
    //@FXML private HBox reportSpam;
    //@FXML private HBox deleteAllMessages;
    //@FXML private HBox deleteAllMessagesGroup;
    @FXML private HBox changeGroupName;
    @FXML private HBox addMember;

    // ---------- Initialize ----------
    public void init(Runnable goLogin, Runnable goFriends, Runnable goAccount) {
        this.goLogin = goLogin;
        this.goFriends = goFriends;
        this.goAccount = goAccount;
    }

    @FXML
    public void initialize() {
        // Enter = send
        chatField.setOnAction(e -> sendMessage());

        // auto-scroll
        chatArea.heightProperty().addListener((obs, oldV, newV) -> chatScrollPane.setVvalue(1.0));

        // Make screen focusable
        screen.setFocusTraversable(true);

        // Chat list filtering
        FilteredList<Conversation> filtered = new FilteredList<>(conversations, c -> true);
        searchChatList.textProperty().addListener((obs, o, q) -> {
            String s = (q == null) ? "" : q.trim().toLowerCase();
            filtered.setPredicate(c -> s.isEmpty() || c.name.toLowerCase().contains(s));
        });

        // When filtered list changes, rebuild chat list UI for added/removed
        filtered.addListener((ListChangeListener<Conversation>) ch -> {
            while (ch.next()) {
                if (ch.wasRemoved()) {
                    for (Conversation r : ch.getRemoved()) removeConversationNode(r.id);
                }
                if (ch.wasAdded()) {
                    for (Conversation a : ch.getAddedSubList()) addConversationNode(a);
                }
            }
        });

        // Message search popover (UI-only)
        VBox searchResultsBox = new VBox();
        searchResultsBox.setPrefWidth(732);
        ScrollPane searchScrollPane = new ScrollPane(searchResultsBox);
        searchScrollPane.setVisible(false);
        searchScrollPane.setMaxHeight(300);
        StackPane.setAlignment(searchScrollPane, Pos.TOP_CENTER);
        StackPane.setMargin(searchScrollPane, new Insets(78, 18, 0, 10));

        screen.setOnMouseClicked(e -> {
            screen.requestFocus();
            searchScrollPane.setVisible(false);
        });

        searchMessage.textProperty().addListener((obs, oldV, newV) -> {
            Platform.runLater(() -> {
                searchResultsBox.getChildren().clear();

                if (focused == null || newV == null || newV.isBlank()) {
                    searchScrollPane.setVisible(false);
                    return;
                }

                String q = newV.toLowerCase();
                List<Msg> list = messagesByConversation.getOrDefault(focused.id, List.of());

                boolean any = false;
                for (Msg m : list) {
                    if (m.text.toLowerCase().contains(q)) {
                        any = true;

                        String preview = m.text.length() > 90 ? m.text.substring(0, 87) + "..." : m.text;
                        Text content = new Text(preview);
                        content.setFontSmoothingType(FontSmoothingType.LCD);
                        TextFlow textFlow = new TextFlow(content);
                        textFlow.setPrefWidth(600);
                        textFlow.getStyleClass().add("message-search");
                        textFlow.setPadding(new Insets(10));

                        Text time = new Text(formatChatTime(m.time));
                        HBox.setMargin(time, new Insets(0, 10, 0, 10));

                        HBox hbox = new HBox(textFlow, time);
                        hbox.setAlignment(Pos.CENTER_LEFT);

                        hbox.setOnMouseClicked(ev -> {
                            VBox target = messageNodeById.get(m.id);
                            if (target != null) {
                                double scrollPosition = target.getBoundsInParent().getMinY() / Math.max(1.0, chatArea.getHeight());
                                chatScrollPane.setVvalue(scrollPosition);

                                target.setStyle("-fx-background-color: yellow;");
                                FadeTransition ft = new FadeTransition(Duration.seconds(1), target);
                                ft.setFromValue(1);
                                ft.setToValue(0.8);
                                ft.setOnFinished(done -> {
                                    target.setStyle(null);
                                    target.setOpacity(1);
                                });
                                ft.play();
                            }
                            searchScrollPane.setVisible(false);
                        });

                        Text sender = new Text(m.sender == null ? "System" : m.sender);
                        VBox vBox = new VBox(sender, hbox);
                        VBox.setMargin(vBox, new Insets(5));

                        searchResultsBox.getChildren().add(vBox);
                    }
                }

                searchScrollPane.setVisible(any);
            });
        });

        searchMessage.setOnMouseClicked(e -> {
            if (focused != null && searchMessage.getText() != null && !searchMessage.getText().isBlank()) {
                searchScrollPane.setVisible(true);
            }
        });

        mainChatContainer.getChildren().add(searchScrollPane);

        // Wire sidebar action placeholders (so clicks do something)
        //if (reportSpam != null) reportSpam.setOnMouseClicked(e -> toastSystem("UI-only: spam report (placeholder)."));
        //if (deleteAllMessages != null) deleteAllMessages.setOnMouseClicked(e -> clearCurrentConversation());
        //if (deleteAllMessagesGroup != null) deleteAllMessagesGroup.setOnMouseClicked(e -> clearCurrentConversation());
        if (changeGroupName != null) changeGroupName.setOnMouseClicked(e -> toastSystem("UI-only: change group name (placeholder)."));
        if (addMember != null) addMember.setOnMouseClicked(e -> toastSystem("UI-only: add member (placeholder)."));

        // Load demo data
        seedDemoData();
    }

    // ---------- FXML actions ----------
    @FXML
    private void logout() {
        SessionState.clear();
        SceneController.setScene("login");
    }


    @FXML
    public void switchToFriendsTab() {
        if (goFriends != null) goFriends.run();
    }

    @FXML
    public void switchToAccountTab() {
        SceneController.setScene("account");
    }

    // ---------- Demo data ----------
    private void seedDemoData() {
        Conversation c1 = new Conversation(1, "Maria Petrova", false);
        Conversation c2 = new Conversation(2, "Project Group", true);
        Conversation c3 = new Conversation(3, "Ahmad", false);

        conversations.setAll(List.of(c1, c2, c3));

        messagesByConversation.put(1L, new ArrayList<>(List.of(
                new Msg(nextId(), 1, "Maria", Instant.now().minusSeconds(3600), "Hi! Are you free today?"),
                new Msg(nextId(), 1, "You", Instant.now().minusSeconds(3500), "Yes, after 6pm."),
                new Msg(nextId(), 1, null, Instant.now().minusSeconds(3400), "System: Maria joined the chat")
        )));

        messagesByConversation.put(2L, new ArrayList<>(List.of(
                new Msg(nextId(), 2, "You", Instant.now().minusSeconds(7200), "I pushed UI changes to the repo."),
                new Msg(nextId(), 2, "Lora", Instant.now().minusSeconds(7100), "Nice, can you also add search?"),
                new Msg(nextId(), 2, "You", Instant.now().minusSeconds(7000), "Yes, adding it now.")
        )));

        messagesByConversation.put(3L, new ArrayList<>(List.of(
                new Msg(nextId(), 3, "Ahmad", Instant.now().minusSeconds(18000), "Assalamu alaikum"),
                new Msg(nextId(), 3, "You", Instant.now().minusSeconds(17900), "Wa alaikum assalam")
        )));

        // update latest for each conversation
        for (Conversation c : conversations) {
            List<Msg> list = messagesByConversation.getOrDefault(c.id, List.of());
            if (!list.isEmpty()) {
                Msg last = list.get(list.size() - 1);
                c.latestMessage = last.text;
                c.latestTime = last.time;
                c.isSeen = true;
            }
        }

        // render them initially
        conversations.forEach(this::addConversationNode);

        // open first conversation
        openConversation(c1);
    }

    // ---------- Conversation list UI ----------
    private void addConversationNode(Conversation c) {
        GridPane pane = createConversationRow(c);
        conversationNodeById.put(c.id, pane);
        chatList.getChildren().add(0, pane);
    }

    private void removeConversationNode(long id) {
        GridPane pane = conversationNodeById.remove(id);
        if (pane != null) chatList.getChildren().remove(pane);
    }

    private GridPane createConversationRow(Conversation c) {
        GridPane conversation = new GridPane();
        conversation.setMinHeight(80);

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(25);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(75);
        conversation.getColumnConstraints().addAll(col1, col2);

        RowConstraints r1 = new RowConstraints();
        r1.setVgrow(Priority.SOMETIMES);
        RowConstraints r2 = new RowConstraints();
        r2.setVgrow(Priority.SOMETIMES);
        conversation.getRowConstraints().addAll(r1, r2);

        // Avatar placeholder (uses CSS + FXML images already, so we keep it simple here)
        Circle circle = new Circle(6, Paint.valueOf("#6be150e0"));
        circle.setStroke(Paint.valueOf("BLACK"));
        circle.setVisible(false);
        GridPane.setMargin(circle, new Insets(0, 0, 0, 57));
        conversation.add(circle, 0, 1);

        Text name = new Text(c.name);
        name.setFont(Font.font("System", FontWeight.BOLD, 18));
        HBox.setMargin(name, new Insets(0, 0, -15, 0));

        Text ts = new Text(c.latestTime == null ? "" : formatConversationTime(c.latestTime));
        HBox.setMargin(ts, new Insets(0, 0, 15, 0));

        HBox info = new HBox(name, ts);
        info.setAlignment(Pos.CENTER_LEFT);
        conversation.add(info, 1, 0);

        Text content = new Text(trimPreview(c.latestMessage, 30));
        content.setFill(c.isSeen ? Color.BLACK : Color.YELLOW);
        GridPane.setValignment(content, VPos.TOP);
        content.setFont(new Font(14));
        conversation.add(content, 1, 1);

        conversation.getStyleClass().add("conversation");
        conversation.setOnMouseClicked(e -> openConversation(c));

        return conversation;
    }

    // ---------- Open + render messages ----------
    private void openConversation(Conversation c) {
        if (focused != null && focused.id == c.id) return;
        focused = c;

        headerName.setText(c.name);
        headerStatus.setText("Online"); // UI-only placeholder

        rightSideBar.setVisible(!c.isGroup);
        rightSideBarGroup.setVisible(c.isGroup);

        if (c.isGroup) {
            rightSideBarGroupName.setText(c.name);
            rightSideBarStatusGroup.setText("Online");
            if (groupMemberContainer != null) {
                groupMemberContainer.getChildren().setAll(
                        new javafx.scene.control.Label("You"),
                        new javafx.scene.control.Label("Lora"),
                        new javafx.scene.control.Label("Yova")
                );
            }
        } else {
            rightSideBarName.setText(c.name);
            rightSideBarStatus.setText("Online");
        }

        mainChatContainer.setVisible(true);

        // load messages for conversation
        List<Msg> list = messagesByConversation.getOrDefault(c.id, new ArrayList<>());
        messages.setAll(list);

        messageNodeById.clear();
        chatArea.getChildren().clear();

        for (Msg m : messages) {
            VBox node = (m.sender == null)
                    ? createSystemMessage(m)
                    : ("You".equals(m.sender) ? createMessageTo(m) : createMessageFrom(m));
            messageNodeById.put(m.id, node);
            chatArea.getChildren().add(node);
        }
    }

    private void sendMessage() {
        if (focused == null) return;

        String text = chatField.getText();
        if (text == null || text.isBlank()) return;

        Msg m = new Msg(nextId(), focused.id, "You", Instant.now(), text.trim());

        messagesByConversation.computeIfAbsent(focused.id, k -> new ArrayList<>()).add(m);
        messages.add(m);

        VBox node = createMessageTo(m);
        messageNodeById.put(m.id, node);
        chatArea.getChildren().add(node);

        // update latest
        focused.latestMessage = m.text;
        focused.latestTime = m.time;

        chatField.clear();
    }

    private void clearCurrentConversation() {
        if (focused == null) return;
        messagesByConversation.put(focused.id, new ArrayList<>());
        messages.clear();
        messageNodeById.clear();
        chatArea.getChildren().clear();
        focused.latestMessage = "";
        focused.latestTime = null;
        toastSystem("All messages cleared (UI-only).");
    }

    // ---------- Message nodes (keep CSS class names) ----------
    private VBox createMessageTo(Msg m) {
        Text t = new Text(m.text);
        t.setFont(Font.font(14));
        t.setFontSmoothingType(FontSmoothingType.LCD);

        TextFlow bubble = new TextFlow(t);
        bubble.setPrefWidth(525);
        bubble.getStyleClass().add("message-to");
        bubble.setPadding(new Insets(10));

        Text time = new Text(formatChatTime(m.time));
        HBox.setMargin(time, new Insets(0, 10, 0, 10));

        HBox row = new HBox(time, bubble);
        row.setAlignment(Pos.CENTER_RIGHT);
        return new VBox(row);
    }

    private VBox createMessageFrom(Msg m) {
        Text t = new Text(m.text);
        t.setFont(Font.font(14));
        t.setFontSmoothingType(FontSmoothingType.LCD);

        TextFlow bubble = new TextFlow(t);
        bubble.setPrefWidth(525);
        bubble.getStyleClass().add("message-from");
        bubble.setPadding(new Insets(10));

        Text time = new Text(formatChatTime(m.time));
        HBox.setMargin(time, new Insets(0, 10, 0, 10));

        HBox row = new HBox(bubble, time);
        row.setAlignment(Pos.CENTER_LEFT);

        Text sender = new Text(m.sender);
        return new VBox(sender, row);
    }

    private VBox createSystemMessage(Msg m) {
        Text t = new Text(m.text);
        t.setFont(Font.font(14));
        t.setFontSmoothingType(FontSmoothingType.LCD);
        t.getStyleClass().add("message-system");

        TextFlow flow = new TextFlow(t);
        flow.setPrefWidth(525);
        flow.setPadding(new Insets(10));
        flow.setTextAlignment(TextAlignment.CENTER);

        HBox row = new HBox(flow);
        row.setAlignment(Pos.CENTER);
        return new VBox(row);
    }

    private void toastSystem(String text) {
        // UI-only: insert a system message into current chat so user sees feedback
        if (focused == null) return;
        Msg sys = new Msg(nextId(), focused.id, null, Instant.now(), "System: " + text);
        messagesByConversation.computeIfAbsent(focused.id, k -> new ArrayList<>()).add(sys);
        messages.add(sys);

        VBox node = createSystemMessage(sys);
        messageNodeById.put(sys.id, node);
        chatArea.getChildren().add(node);
    }

    // ---------- Helpers ----------
    private static String trimPreview(String s, int max) {
        if (s == null) return "";
        String t = s.trim();
        return t.length() > max ? t.substring(0, max - 3) + "..." : t;
    }

    private static final DateTimeFormatter CHAT_TIME =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm").withZone(ZoneId.systemDefault());

    private static String formatChatTime(Instant t) {
        return CHAT_TIME.format(t);
    }

    private static String formatConversationTime(Instant t) {
        long minutes = TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - t.toEpochMilli());
        if (minutes < 1) return "Just now";
        if (minutes < 60) return minutes + "m";
        if (minutes < 60 * 24) return (minutes / 60) + "h";
        if (minutes < 60 * 24 * 7) return (minutes / (60 * 24)) + "d";
        if (minutes < 60 * 24 * 365) return (minutes / (60 * 24 * 7)) + "w";
        return (minutes / (60 * 24 * 365)) + "y";
    }

    private static long ID_SEQ = 1000;
    private static long nextId() { return ++ID_SEQ; }
}
