package bg.chatroom.ui.controllers;

import bg.chatroom.model.User;
import bg.chatroom.ui.state.SessionState;
import bg.chatroom.ui.util.SceneController;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.time.LocalDate;

public class AccountController {

    // === FXML fields ===
    @FXML private GridPane screen;

    @FXML private TextField username;
    @FXML private PasswordField password;
    @FXML private TextField name;
    @FXML private TextField address;
    @FXML private TextField sex;
    @FXML private DatePicker birthdate;
    @FXML private TextField email;

    @FXML private Button save;
    @FXML private Button discard;

    @FXML
    public void initialize() {
        // Make screen focusable
        screen.setFocusTraversable(true);
        screen.setOnMouseClicked(e -> screen.requestFocus());

        // Button actions
        save.setOnAction(e -> onSave());
        discard.setOnAction(e -> fillFromSession());

        // Initial populate
        fillFromSession();
    }

    // === Navigation handlers referenced by FXML ===
    @FXML
    private void logout() {
        SessionState.clear();
        SceneController.setScene("login");
    }

    @FXML
    private void switchToChatTab() {
        SceneController.setScene("chat");
    }

    @FXML
    private void switchToFriendsTab() {
        SceneController.setScene("friends");
    }

    // === UI-only save (mock) ===
    private void onSave() {
        if (!SessionState.isLoggedIn()) {
            showError("Not logged in.");
            return;
        }

        User current = SessionState.getCurrentUser();

        // Update fields (UI-only; later you’ll call a real AccountService)
        current.setUsername(safeTrim(username.getText()));
        current.setName(safeTrim(name.getText()));
        current.setEmail(safeTrim(email.getText()));
        current.setAddress(safeTrim(address.getText()));
        current.setSex(safeTrim(sex.getText()));

        LocalDate bd = birthdate.getValue();
        current.setBirthdate(bd);

        // Password: only update if user typed something
        String newPass = password.getText();
        if (newPass != null && !newPass.isBlank()) {
            current.setPassword(newPass);
            password.clear();
        }

        showInfo("Account updated (mock).");
        fillFromSession(); // refresh UI to reflect stored data format
    }

    private void fillFromSession() {
        if (!SessionState.isLoggedIn()) {
            // If user somehow opens account without login, just go back
            SceneController.setScene("login");
            return;
        }

        User u = SessionState.getCurrentUser();

        username.setText(nullToEmpty(u.getUsername()));
        name.setText(nullToEmpty(u.getName()));
        email.setText(nullToEmpty(u.getEmail()));
        address.setText(nullToEmpty(u.getAddress()));
        sex.setText(nullToEmpty(u.getSex()));

        birthdate.setValue(u.getBirthdate()); // LocalDate
        password.clear();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Account");
        a.setHeaderText(msg);
        a.showAndWait();
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Account");
        a.setHeaderText(msg);
        a.showAndWait();
    }

    private static String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
