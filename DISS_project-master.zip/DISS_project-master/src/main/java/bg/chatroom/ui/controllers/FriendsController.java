package bg.chatroom.ui.controllers;

import bg.chatroom.ui.state.SessionState;
import bg.chatroom.ui.util.SceneController;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;

public class FriendsController {

    @FXML
    private void logout() {
        SessionState.clear();
        SceneController.setScene("login");
    }

    @FXML
    private void switchToChatTab() {
        SceneController.setScene("chat");
    }

    @FXML
    private void switchToAccountTab() {
        SceneController.setScene("account");
    }

    @FXML
    private void searchForUsers() {
        // UI-only for now
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Friends");
        a.setHeaderText("searchForUsers() is not implemented yet (UI mock).");
        a.showAndWait();
    }
}
