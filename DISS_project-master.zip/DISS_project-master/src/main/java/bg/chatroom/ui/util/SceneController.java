package bg.chatroom.ui.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;

public final class SceneController {
    public static javafx.stage.Stage primaryStage;
    public static HashMap<String, Scene> scenes = new HashMap<>();

    private SceneController() {}

    public static void addScene(String name, String fxmlPath, String cssPath) throws IOException {
        URL fxmlUrl = SceneController.class.getResource("/" + fxmlPath);
        if (fxmlUrl == null) {
            throw new IllegalStateException("FXML not found on classpath: /" + fxmlPath);
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Scene scene = new Scene(loader.load());

        if (cssPath != null && !cssPath.isBlank()) {
            URL cssUrl = SceneController.class.getResource("/" + cssPath);
            if (cssUrl == null) {
                throw new IllegalStateException("CSS not found on classpath: /" + cssPath);
            }
            scene.getStylesheets().add(cssUrl.toExternalForm());
        }

        scenes.put(name, scene);
    }

    public static void initScenes() {
        try {
            addScene("login", "gui/login.fxml", "stylesheets/style.css");
            addScene("register", "gui/signup.fxml", "stylesheets/style.css");
            addScene("chat", "gui/chat.fxml", "stylesheets/style.css");
            addScene("account", "gui/account.fxml", "stylesheets/style.css");
            addScene("friends", "gui/friends.fxml", "stylesheets/style.css");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void setPrimaryStage(javafx.stage.Stage stage, String firstSceneName) {
        primaryStage = stage;
        initScenes();
        setScene(firstSceneName);
        primaryStage.show();
    }

    public static void setScene(String name) {
        Scene s = scenes.get(name);
        if (s == null) throw new IllegalStateException("Scene not registered: " + name);
        primaryStage.setScene(s);
        primaryStage.show();
    }
}
