package bg.chatroom.ui.controllers;

import bg.chatroom.di.ServiceLocator;
import bg.chatroom.model.User;
import bg.chatroom.services.AuthService;
import bg.chatroom.ui.state.SessionState;
import bg.chatroom.ui.util.SceneController;
import bg.chatroom.validation.Validators;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.util.function.UnaryOperator;

public class SignupController {

    @FXML private VBox fieldContainer;

    @FXML private TextField name;
    @FXML private TextField username;
    @FXML private TextField email;

    @FXML private PasswordField password;
    @FXML private PasswordField confirmPassword;

    @FXML private HBox screen;

    @FXML private HBox alert;
    @FXML private Text alertText;

    private final AuthService authService = ServiceLocator.auth();

    @FXML
    public void initialize() {
        screen.setFocusTraversable(true);
        alert.setVisible(false);

        screen.setOnKeyReleased(event -> {
            if (event.getCode() == KeyCode.ENTER) handleRegister();
        });

        screen.setOnMouseClicked(e -> screen.requestFocus());

        UnaryOperator<TextFormatter.Change> limit32 =
                c -> (c.getControlNewText().length() > 32) ? null : c;

        username.setTextFormatter(new TextFormatter<>(limit32));
        password.setTextFormatter(new TextFormatter<>(limit32));
        confirmPassword.setTextFormatter(new TextFormatter<>(limit32));


        displayErrorField(name, "name", 2);
        displayErrorField(username, "username", 5);
        displayErrorField(email, "email", 8);
        displayErrorField(password, "password", 11);
        displayErrorField(confirmPassword, "confirm password", 14);
    }

    private <T extends TextField> void displayErrorField(T field, String element, int index) {
        Text error = new Text("Enter your " + element);
        error.setStyle("-fx-fill: red;");
        fieldContainer.getChildren().add(index, error);
        error.setVisible(false);

        field.focusedProperty().addListener((obs, oldV, newV) -> {
            if (!newV) { // lost focus
                validateField(field, element, error);
            } else { // gained focus
                field.getStyleClass().remove("error");
                error.setVisible(false);
            }
        });
    }

    private void validateField(TextField field, String element, Text error) {
        String value = field.getText();

        if (value == null || value.isBlank()) {
            field.getStyleClass().add("error");
            error.setText("Enter your " + element);
            error.setVisible(true);
            return;
        }

        switch (element) {
            case "username" -> {
                var r = Validators.validateUsername(value);
                if (!r.ok()) {
                    field.getStyleClass().add("error");
                    error.setText(r.message());
                    error.setVisible(true);
                }
            }
            case "email" -> {
                var r = Validators.validateEmail(value);
                if (!r.ok()) {
                    field.getStyleClass().add("error");
                    error.setText(r.message());
                    error.setVisible(true);
                }
            }
            case "password" -> {
                var r = Validators.validatePassword(value);
                if (!r.ok()) {
                    field.getStyleClass().add("error");
                    error.setText(r.message());
                    error.setVisible(true);
                }
            }
            case "confirm password" -> {
                if (!value.equals(password.getText())) {
                    field.getStyleClass().add("error");
                    error.setText("Passwords do not match.");
                    error.setVisible(true);
                }
            }
        }
    }

    @FXML
    private void switchToLogin() {
        SceneController.setScene("login");
    }

    @FXML
    private void register() {
        handleRegister();
    }

    private void handleRegister() {
        alert.setVisible(false);

        //  errors
        if (hasError(name) || hasError(username) || hasError(email) || hasError(password) || hasError(confirmPassword)) {
            showError("Please fix the highlighted fields.");
            return;
        }

        // final validation
        var u = Validators.validateUsername(username.getText());
        if (!u.ok()) { showError(u.message()); return; }

        var e = Validators.validateEmail(email.getText());
        if (!e.ok()) { showError(e.message()); return; }

        var p = Validators.validatePassword(password.getText());
        if (!p.ok()) { showError(p.message()); return; }

        if (!confirmPassword.getText().equals(password.getText())) {
            showError("Passwords do not match.");
            return;
        }

        var result = authService.register(username.getText(), email.getText(), password.getText());
        if (!result.ok()) {
            showError(result.message());
            return;
        }

        // mock login after signup
        User user = new User();
        user.setUsername(username.getText());
        user.setEmail(email.getText());
        user.setName(name.getText());

        SessionState.setCurrentUser(user);

        // go to chat
        SceneController.setScene("chat");
    }

    private boolean hasError(TextField f) {
        return f.getStyleClass().contains("error");
    }

    private void showError(String msg) {
        alertText.setText(msg);
        alert.setVisible(true);
    }
}

