package bg.chatroom.ui;

import bg.chatroom.services.AuthService;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class RegisterView {

    private final BorderPane root = new BorderPane();

    public RegisterView(AuthService authService, Runnable goLogin) {
        root.setPadding(new Insets(24));

        Label title = new Label("Register");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        TextField username = new TextField();
        username.setPromptText("User name");

        TextField email = new TextField();
        email.setPromptText("Email");

        PasswordField password = new PasswordField();
        password.setPromptText("Password (6–32, A-z, 0-9, _-@!)");

        Label error = new Label();
        error.setStyle("-fx-text-fill: #b00020;");

        Button submit = new Button("Create Profile");
        submit.setDefaultButton(true);

        Button back = new Button("Logout");

        submit.setOnAction(e -> {
            var res = authService.register(username.getText(), email.getText(), password.getText());
            if (res.ok()) {
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Profile is created (mock). Login.");
                a.showAndWait();
                goLogin.run();
            } else {
                error.setText(res.message());
            }
        });

        back.setOnAction(e -> goLogin.run());

        VBox card = new VBox(10, title, username, email, password, error, submit, back);
        card.setPadding(new Insets(18));
        card.setMaxWidth(420);
        card.setStyle("""
                -fx-background-color: white;
                -fx-background-radius: 12;
                -fx-border-radius: 12;
                -fx-border-color: #e0e0e0;
                """);

        root.setCenter(new StackPane(card));
        root.setStyle("-fx-background-color: #f6f7fb;");
    }

    public Parent getRoot() { return root; }
}
